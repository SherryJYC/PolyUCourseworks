numOfBertsToys = 10
stuffedAnimals = ['muffins', 'bonkers', 'grumpy', 'ed']
numberOfStuffies = len(stuffedAnimals)
per = int(numberOfStuffies/numOfBertsToys * 100)
print("{}%".format(per))
