str1="Hello"
str2="World!"
q1scores = [76, 89, 90]
q2scores = [33, 40, 20]
students = ["John", "Dick", "Harry"]
str3 = str1 + " " + str2
print(len(str3))