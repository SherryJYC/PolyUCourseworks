myStr = "The Hong Kong Polytechnic University"
s = myStr.split()

print("{} {} {} {} {}".format(s[3][3], s[4][2], s[4][5], s[4][3], s[2][2]))

