myStr = "The Hong Kong Polytechnic University"
print(myStr[::-1])                                                                                                                  