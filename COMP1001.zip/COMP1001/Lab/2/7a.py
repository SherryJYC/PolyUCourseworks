word = "hi"
myList = ["hello", "hi", "ni hao", "annyong", "bonjour", "ciao"]
for p in myList:
    if word == p:
        print("Yes")
        break
else:
    print("No")
