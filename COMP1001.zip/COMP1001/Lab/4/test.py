import Exercise1, Exercise2

print("Test for Exercise 1:")
Exercise1.inputData()

print("Test for Exercise 2:")
Exercise2.main()

