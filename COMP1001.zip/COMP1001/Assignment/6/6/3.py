def func(min, max, opr):
    if opr == "+":
        try:
            result = max + min

        return max + min
    elif opr == "-":
        return max - min
    elif opr == "*":
        return max * min
    elif opr == "/":
        return max / min